package net.triax.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.triax.visual.gui.ClickGuiScreen;
import net.triax.visual.render.TrailRenderer;
import org.lwjgl.glfw.GLFW;

/**
 * Triax Visual — клиентский визуальный мод.
 * Right Shift открывает ClickGUI, в котором можно включить модуль Trail.
 */
public class TriaxVisualClient implements ClientModInitializer {

    public static final String MOD_ID = "triaxvisual";

    /** Глобальный флаг: включен ли трейл. Читается GUI и рендером. */
    public static boolean trailEnabled = false;

    private static KeyBinding openGuiKey;
    private static final TrailRenderer TRAIL_RENDERER = new TrailRenderer();

    @Override
    public void onInitializeClient() {

        // Регистрируем клавишу открытия GUI — по умолчанию Right Shift.
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triaxvisual.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.triaxvisual.main"
        ));

        // Каждый клиентский тик: проверяем нажатие клавиши и обновляем позиции трейла.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }

            if (trailEnabled && client.player != null) {
                TRAIL_RENDERER.tick(client.player);
            } else {
                TRAIL_RENDERER.clearIfEmpty();
            }
        });

        // Рендер трейла в мире, после отрисовки сущностей.
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (trailEnabled) {
                TRAIL_RENDERER.render(context);
            }
        });
    }

    public static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }
}
