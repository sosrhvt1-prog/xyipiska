package net.triax.visual.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.triax.visual.TriaxVisualClient;

/**
 * Простой ClickGUI мода Triax Visual.
 * Открывается по Right Shift. Содержит одну панель модулей с переключателем Trail.
 */
public class ClickGuiScreen extends Screen {

    private static final int PANEL_WIDTH = 160;
    private static final int PANEL_TITLE_HEIGHT = 24;
    private static final int BUTTON_HEIGHT = 20;
    private static final int PADDING = 8;

    private int panelX;
    private int panelY;

    private ButtonWidget trailButton;

    public ClickGuiScreen() {
        super(Text.literal("Triax Visual"));
    }

    @Override
    protected void init() {
        panelX = (this.width - PANEL_WIDTH) / 2;
        panelY = (this.height - (PANEL_TITLE_HEIGHT + BUTTON_HEIGHT + PADDING * 2)) / 2;

        trailButton = ButtonWidget.builder(trailButtonText(), btn -> {
                    TriaxVisualClient.trailEnabled = !TriaxVisualClient.trailEnabled;
                    btn.setMessage(trailButtonText());
                })
                .dimensions(panelX + PADDING, panelY + PANEL_TITLE_HEIGHT + PADDING,
                        PANEL_WIDTH - PADDING * 2, BUTTON_HEIGHT)
                .build();

        this.addDrawableChild(trailButton);
    }

    private Text trailButtonText() {
        String state = TriaxVisualClient.trailEnabled ? "ON" : "OFF";
        int color = TriaxVisualClient.trailEnabled ? 0x55FF55 : 0xFF5555;
        return Text.literal("Trail: " + state);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Полупрозрачный фон, чтобы видеть мир позади GUI.
        this.renderBackground(context, mouseX, mouseY, delta);

        int panelHeight = PANEL_TITLE_HEIGHT + BUTTON_HEIGHT + PADDING * 2;

        // Фон панели.
        context.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + panelHeight, 0xCC101014);
        // Рамка панели.
        context.drawBorder(panelX, panelY, PANEL_WIDTH, panelHeight, 0xFF3A3A50);
        // Заголовок.
        context.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + PANEL_TITLE_HEIGHT, 0xE6202030);
        context.drawCenteredTextWithShadow(this.textRenderer, "Triax Visual",
                panelX + PANEL_WIDTH / 2, panelY + PANEL_TITLE_HEIGHT / 2 - 4, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
