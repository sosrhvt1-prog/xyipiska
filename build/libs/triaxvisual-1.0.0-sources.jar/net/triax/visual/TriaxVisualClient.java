package net.triax.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.triax.visual.gui.ClickGuiScreen;
import net.triax.visual.render.TrailRenderer;
import org.lwjgl.glfw.GLFW;

/**
 * Triax Visual — клиентский визуальный мод.
 * Right Shift открывает ClickGUI, в котором можно включить модуль Trail.
 */
public class TriaxVisualClient implements ClientModInitializer {

    public static final String MOD_ID = "triaxvisual";

    /** Глобальный флаг: включен ли трейл. Читается GUI и рендером. */
    public static boolean trailEnabled = false;

    private static class_304 openGuiKey;
    private static final TrailRenderer TRAIL_RENDERER = new TrailRenderer();

    @Override
    public void onInitializeClient() {

        // Регистрируем клавишу открытия GUI — по умолчанию Right Shift.
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.triaxvisual.opengui",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.triaxvisual.main"
        ));

        // Каждый клиентский тик: проверяем нажатие клавиши и обновляем позиции трейла.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ClickGuiScreen());
                }
            }

            if (trailEnabled && client.field_1724 != null) {
                TRAIL_RENDERER.tick(client.field_1724);
            } else {
                TRAIL_RENDERER.clearIfEmpty();
            }
        });

        // Рендер трейла в мире, после отрисовки сущностей.
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (trailEnabled) {
                TRAIL_RENDERER.render(context);
            }
        });
    }

    public static class_310 mc() {
        return class_310.method_1551();
    }
}
