package net.triax.visual.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.triax.visual.TriaxVisualClient;

/**
 * Простой ClickGUI мода Triax Visual.
 * Открывается по Right Shift. Содержит одну панель модулей с переключателем Trail.
 */
public class ClickGuiScreen extends class_437 {

    private static final int PANEL_WIDTH = 160;
    private static final int PANEL_TITLE_HEIGHT = 24;
    private static final int BUTTON_HEIGHT = 20;
    private static final int PADDING = 8;

    private int panelX;
    private int panelY;

    private class_4185 trailButton;

    public ClickGuiScreen() {
        super(class_2561.method_43470("Triax Visual"));
    }

    @Override
    protected void method_25426() {
        panelX = (this.field_22789 - PANEL_WIDTH) / 2;
        panelY = (this.field_22790 - (PANEL_TITLE_HEIGHT + BUTTON_HEIGHT + PADDING * 2)) / 2;

        trailButton = class_4185.method_46430(trailButtonText(), btn -> {
                    TriaxVisualClient.trailEnabled = !TriaxVisualClient.trailEnabled;
                    btn.method_25355(trailButtonText());
                })
                .method_46434(panelX + PADDING, panelY + PANEL_TITLE_HEIGHT + PADDING,
                        PANEL_WIDTH - PADDING * 2, BUTTON_HEIGHT)
                .method_46431();

        this.method_37063(trailButton);
    }

    private class_2561 trailButtonText() {
        String state = TriaxVisualClient.trailEnabled ? "ON" : "OFF";
        int color = TriaxVisualClient.trailEnabled ? 0x55FF55 : 0xFF5555;
        return class_2561.method_43470("Trail: " + state);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Полупрозрачный фон, чтобы видеть мир позади GUI.
        this.method_25420(context, mouseX, mouseY, delta);

        int panelHeight = PANEL_TITLE_HEIGHT + BUTTON_HEIGHT + PADDING * 2;

        // Фон панели.
        context.method_25294(panelX, panelY, panelX + PANEL_WIDTH, panelY + panelHeight, 0xCC101014);
        // Рамка панели.
        context.method_49601(panelX, panelY, PANEL_WIDTH, panelHeight, 0xFF3A3A50);
        // Заголовок.
        context.method_25294(panelX, panelY, panelX + PANEL_WIDTH, panelY + PANEL_TITLE_HEIGHT, 0xE6202030);
        context.method_25300(this.field_22793, "Triax Visual",
                panelX + PANEL_WIDTH / 2, panelY + PANEL_TITLE_HEIGHT / 2 - 4, 0xFFFFFF);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}
