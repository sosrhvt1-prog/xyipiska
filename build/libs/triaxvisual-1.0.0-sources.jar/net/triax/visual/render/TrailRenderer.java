package net.triax.visual.render;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Хранит недавние позиции игрока и рисует за ним плавный радужный след,
 * который затухает (fade out) по мере удаления от игрока.
 */
public class TrailRenderer {

    /** Сколько последних позиций хранить в трейле. Больше = длиннее след. */
    private static final int MAX_POINTS = 60;

    /** Толщина линии трейла. */
    private static final float LINE_WIDTH = 3.0f;

    /** Скорость смены цвета радуги (циклов в секунду примерно). */
    private static final float RAINBOW_SPEED = 0.6f;

    private final Deque<class_243> points = new ArrayDeque<>();
    private long lastTickTime = 0;

    public void tick(class_1657 player) {
        class_243 pos = player.method_19538().method_1031(0, player.method_17682() / 2.0, 0);
        points.addLast(pos);
        while (points.size() > MAX_POINTS) {
            points.removeFirst();
        }
    }

    /** Если трейл выключен, постепенно очищаем точки, чтобы след плавно исчезал. */
    public void clearIfEmpty() {
        if (!points.isEmpty()) {
            points.removeFirst();
        }
    }

    public void render(WorldRenderContext context) {
        if (points.size() < 2) return;

        class_4597.class_4598 consumers =
                (class_4597.class_4598) context.consumers();
        if (consumers == null) return;

        class_4587 matrices = context.matrixStack();
        if (matrices == null) return;

        class_243 camPos = context.camera().method_19326();

        matrices.method_22903();
        matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);

        Matrix4f positionMatrix = matrices.method_23760().method_23761();
        class_4588 buffer = consumers.getBuffer(class_1921.method_34572());

        List<class_243> ordered = new ArrayList<>(points);
        int count = ordered.size();

        float time = (System.currentTimeMillis() % 100000) / 1000f;

        for (int i = 0; i < count; i++) {
            class_243 p = ordered.get(i);

            // Прогресс от 0 (старая точка, хвост) до 1 (свежая точка, у игрока)
            float progress = i / (float) (count - 1);

            // Радужный цвет, циклически сдвигающийся по времени
            float hue = (progress + time * RAINBOW_SPEED) % 1.0f;
            int color = hsvToRgb(hue, 0.85f, 1.0f);

            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            // Затухание: хвост почти прозрачный, у игрока — почти непрозрачный
            float alpha = class_3532.method_15363(progress, 0.05f, 1.0f);

            buffer.method_22918(positionMatrix, (float) p.field_1352, (float) p.field_1351, (float) p.field_1350)
                    .method_22915(r, g, b, alpha)
                    .method_22914(0, 1, 0);
        }

        consumers.method_22994(class_1921.method_34572());
        matrices.method_22909();
    }

    private static int hsvToRgb(float h, float s, float v) {
        int i = (int) (h * 6f);
        float f = h * 6f - i;
        float p = v * (1f - s);
        float q = v * (1f - f * s);
        float t = v * (1f - (1f - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
